package models;

public class AdminModel extends User{   
    public AdminModel(String username, String password) {
        super(username, password);
    }
}